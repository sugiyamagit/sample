import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.fabric8.kubernetes.api.model.Pod;
import io.fabric8.openshift.client.DefaultOpenShiftClient;
import io.fabric8.openshift.client.OpenShiftClient;

/**
 *
 * @author d532139
 *
 */
public class OpenshiftClientTest {
	/** comment */
	private static final Logger LOG = LoggerFactory.getLogger(OpenshiftClientTest.class.getName());

	/** comment */
	private static final int MAX_WAIT_MILSEC = 5000;

	/**
	 *
	 * @param projectName
	 * @param deploymentConfigName
	 * @param icount
	 */
	public static void replicaCountSet(String projectName, String deploymentConfigName, int icount) {


        LOG.info("ReplicaCountSet Start ==============================");
    	try (OpenShiftClient osClient = new DefaultOpenShiftClient();) {
    		// Replica数の設定
	        osClient.deploymentConfigs().inNamespace(projectName).withName(deploymentConfigName).scale(icount,true);

	        // PodがReadyになるまで待つ
            do{
            	Thread.sleep(MAX_WAIT_MILSEC);
            	LOG.info("{}.pods.isReady={}", deploymentConfigName, osClient.deploymentConfigs().inNamespace(projectName).withName(deploymentConfigName).isReady());
            } while (!osClient.deploymentConfigs().inNamespace(projectName).withName(deploymentConfigName).isReady());

    	} catch (InterruptedException e) {
    		LOG.error("error occured. ", e);
    	}
    	LOG.info("ReplicaCountSet End ================================");
	}

	/**
	 *
	 * @param projectName
	 * @param deploymentConfigName
	 */
	public static void podForcedStop(String projectName, String deploymentConfigName) {

		LOG.info("podForcedStop Start ==============================");
    	try (OpenShiftClient osClient = new DefaultOpenShiftClient();) {
	        // deploymentConfigNameからpod名を取得
	        Pod pod = osClient.pods().inNamespace(projectName).withLabel("name", deploymentConfigName).list().getItems().get(0);
	        // podを強制停止
	        osClient.pods().inNamespace(projectName).withName(pod.getMetadata().getName()).withGracePeriod(0).delete();
    	}
    	LOG.info("podForcedStop End ================================");
	}

	/**
	 *
	 * @param projectName
	 * @param statefulsetsName
	 */
	public static void podForcedStopStateful(String projectName, String statefulsetsName) {

		LOG.info("podForcedStopStarteful Start ==============================");
    	try (OpenShiftClient osClient = new DefaultOpenShiftClient();) {
			// statefulsetに属しているPodの一覧を取得（statefulset.kubernetes.io/pod-name）
			List<Pod> podList = osClient.pods().inNamespace(projectName).withLabel("statefulset.kubernetes.io/pod-name").list().getItems();

			// Podの一覧から、pod名がstatefulset名で始まるものを探し、先頭の1件目を取得
			Optional<Pod> opPod = podList.stream().filter(pod -> pod.getMetadata().getName().startsWith(statefulsetsName)).findFirst();

			// podを強制停止する
			opPod.ifPresent(pod -> osClient.pods().inNamespace(projectName).withName(pod.getMetadata().getName()).withGracePeriod(0).delete());
//	        osClient.pods().inNamespace(projectName).withName(statefulsetsName).withGracePeriod(0).delete();
    	}
    	LOG.info("podForcedStopStarteful End ================================");
	}
}
