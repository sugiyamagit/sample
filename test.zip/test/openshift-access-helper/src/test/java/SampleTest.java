import org.junit.Test;

public class SampleTest {

	// mvnコマンドに-Dオプションで指定する。
	private static final String PROJECT_NAME_KEY = "test.openshift.projectName";
	private static final String DEPLOYMENT_CONFIG_NAME_KEY = "test.openshift.deploymentConfig";
	private static final String STATEFULSET_NAME_KEY = "test.openshift.statefulsetName";

    @Test
    public void replicaCountSetTest() {
        OpenshiftClientTest.replicaCountSet(System.getProperty(PROJECT_NAME_KEY), System.getProperty(DEPLOYMENT_CONFIG_NAME_KEY), 5);
    }

    @Test
    public void podForcedStopTest() {
        OpenshiftClientTest.podForcedStop(System.getProperty(PROJECT_NAME_KEY), System.getProperty(DEPLOYMENT_CONFIG_NAME_KEY));
    }

    @Test
    public void podForcedStopStateful() {
        OpenshiftClientTest.podForcedStopStateful(System.getProperty(PROJECT_NAME_KEY), System.getProperty(STATEFULSET_NAME_KEY));
    }

}
