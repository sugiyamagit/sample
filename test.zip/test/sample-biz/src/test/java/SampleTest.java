import static org.junit.Assert.*;

import org.junit.Test;

public class SampleTest {
//	private static final String PROJECT_NAME_KEY = "test.openshift.projectName";
//	private static final String DEPLOYMENT_CONFIG_NAME_KEY = "test.openshift.deploymentConfig";
//	private static final String STATEFULSET_NAME_KEY = "test.openshift.statefulsetName";

	private static final String PROJECT_NAME = "sandbox-sugiyama";
	private static final String DEPLOYMENT_CONFIG_NAME = "httpd-example";
	private static final String STATEFULSET_NAME = "sample-statefulset";
	private static final int REPLICA_COUNT = 5;


    @Test
    public void replicaCountSetTest() {

    	// biz app's test code here

    	// change replicaCount
    	OpenshiftClientTest.replicaCountSet(PROJECT_NAME, DEPLOYMENT_CONFIG_NAME, REPLICA_COUNT);

    	// biz app's test code here

    	// assert sample
    	assertEquals("sample assert", true, true);

    }

    @Test
    public void podForcedStopTest() {
        OpenshiftClientTest.podForcedStop(PROJECT_NAME, DEPLOYMENT_CONFIG_NAME);
    }

    @Test
    public void podForcedStopStateful() {
        OpenshiftClientTest.podForcedStopStateful(PROJECT_NAME, STATEFULSET_NAME);
    }

}
